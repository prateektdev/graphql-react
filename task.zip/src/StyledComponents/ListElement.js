import styled from "styled-components";

const ListElement = styled.li` 
margin:1px 0px 1px 0px;
`;
export default ListElement;