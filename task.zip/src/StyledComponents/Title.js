import styled from "styled-components";

const Title = styled.h1`
  font-size: 1.5em;
  display:block;
  text-align: center;
  color: #0d6efd;
`;
export default Title;